#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Alarm handler function
void alarm_handler() {
  printf("Alarm triggered!\n");
  sigreturn();  // Call sigreturn() to resume where we left off
}

int main() {
  // Set the alarm to trigger every 10 ticks
  sigalarm(10, alarm_handler);

  // Busy loop to consume CPU time
  int i = 0;
  while (1) {
    if (i % 1000000 == 0) {
      printf("Working... %d\n", i);
    }
    i++;
  }

  // We should never reach here
  exit(0);
}
