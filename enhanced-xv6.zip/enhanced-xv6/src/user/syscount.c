#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

// Array of syscall names corresponding to syscall numbers
const char *syscall_names[] = {
    "fork",    // SYS_fork
    "exit",    // SYS_exit
    "wait",    // SYS_wait
    "pipe",    // SYS_pipe
    "read",    // SYS_read
    "kill",    // SYS_kill
    "exec",    // SYS_exec
    "fstat",   // SYS_fstat
    "chdir",   // SYS_chdir
    "dup",     // SYS_dup
    "getpid",  // SYS_getpid
    "sbrk",    // SYS_sbrk
    "sleep",   // SYS_sleep
    "uptime",  // SYS_uptime
    "open",    // SYS_open
    "write",   // SYS_write
    "mknod",   // SYS_mknod
    "unlink",  // SYS_unlink
    "link",    // SYS_link
    "mkdir",   // SYS_mkdir
    "close",   // SYS_close
    "waitx",   // SYS_waitx
    "getsyscount", // SYS_getsyscount
    "sigalarm", // SYS_sigalarm
    "sigreturn", // SYS_sigreturn
    "settickets" // SYS_settickets
};

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(2, "Usage: syscount <mask> <command> [args]\n");
        exit(1);  // Exiting with an error status
    }

    int mask = atoi(argv[1]);
    int pid = fork();

    if (pid < 0) {
        fprintf(2, "Error: fork failed\n");
        exit(1);  // Fork failed
    } else if (pid == 0) {
        // Child process: Execute the command
        exec(argv[2], &argv[2]);
        fprintf(2, "Error: exec failed\n");
        exit(1);  // Exec failed
    } else {
        // Parent process: Wait for the child to finish
        wait(0);  // Properly wait for child

        // Call getsyscount and print the result
        int count = getsyscount(mask);  // Ensure this function name matches your system
        if (count < 0) {
            fprintf(2, "Error: getsyscount failed\n");
        } else {
            // Determine the syscall index from the mask
            int syscall_index = -1;
            for (int i = 0; i < sizeof(syscall_names) / sizeof(syscall_names[0]); i++) {
                if (mask == (1 << i)) {
                    syscall_index = i-1;
                    break;
                }
            }

            // Print the syscall name and count
            if (syscall_index >= 0) {
                printf("PID %d called %s %d times.\n", pid, syscall_names[syscall_index], count);
            } else {
                printf("Invalid mask: %d\n", mask);
            }
        }
        exit(0);  // Successful exit
    }

    return 0;
}
